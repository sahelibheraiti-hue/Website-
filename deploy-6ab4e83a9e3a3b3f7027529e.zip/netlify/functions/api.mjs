import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

const store = getStore("saheli-store");

const DEFAULT_CATEGORIES = [
  "Oil","Cream","Facewash","Body Spray & Perfume","Shampoo",
  "Hair Removal Creams","Oral Care","Beauty Care","Parlor Accessories",
  "Chocolate & Cookies","Body Lotion","Makeup","Hair Care","Skincare",
  "Personal Care","Nail Care","Makeup Accessories","Other"
];

const DEFAULT_PRODUCTS = [
  {id:"p1",name:"Hair Oil",category:"Oil",price:199,size:"100 ml",stock:20,image:"",description:"Everyday hair care oil."},
  {id:"p2",name:"Face Wash",category:"Facewash",price:249,size:"100 ml",stock:15,image:"",description:"Gentle daily face wash."},
  {id:"p3",name:"Body Lotion",category:"Body Lotion",price:299,size:"200 ml",stock:12,image:"",description:"Moisturizing body lotion."},
  {id:"p4",name:"Lipstick",category:"Makeup",price:399,size:"1 pc",stock:10,image:"",description:"Beautiful everyday lipstick."},
  {id:"p5",name:"Foundation",category:"Makeup",price:499,size:"30 ml",stock:8,image:"",description:"Smooth coverage foundation."},
  {id:"p6",name:"Perfume",category:"Body Spray & Perfume",price:599,size:"50 ml",stock:8,image:"",description:"Fresh long-lasting fragrance."}
];

function json(data,status=200){
  return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
}
async function body(req){ try{return await req.json()}catch{return {}} }
async function get(key,fallback){ const v=await store.get(key,{type:"json"}); return v ?? fallback; }
async function set(key,v){ await store.setJSON(key,v); }

function hashPassword(password,salt){
  return crypto.scryptSync(password,salt,64).toString("hex");
}
function passwordMatches(password,record){
  if(!record?.hash||!record?.salt) return false;
  const h=hashPassword(password,record.salt);
  return crypto.timingSafeEqual(Buffer.from(h,"hex"),Buffer.from(record.hash,"hex"));
}
function sign(value){
  const secret=process.env.SESSION_SECRET || "Saheli-Bherayti-Session-Secret-845107-Change-In-Netlify";
  return crypto.createHmac("sha256",secret).update(value).digest("hex");
}
function makeSession(){
  const payload=Buffer.from(JSON.stringify({exp:Date.now()+1000*60*60*12,role:"admin"})).toString("base64url");
  return `${payload}.${sign(payload)}`;
}
function isAdmin(req){
  const c=req.headers.get("cookie")||"";
  const m=c.match(/saheli_admin=([^;]+)/);
  if(!m) return false;
  const [payload,sig]=m[1].split(".");
  if(!payload||!sig||sig!==sign(payload)) return false;
  try{return JSON.parse(Buffer.from(payload,"base64url").toString()).exp>Date.now()}catch{return false}
}
function today(){return new Date().toLocaleDateString("en-CA",{timeZone:"Asia/Kolkata"});}
function cleanPhone(p){return String(p||"").replace(/\D/g,"").slice(-10);}
function randomVoucher(){return Math.floor(Math.random()*100)+1;}
function voucherCode(){return "SAHELI-"+crypto.randomBytes(4).toString("hex").toUpperCase();}

async function seed(){
  if(await store.get("meta/seeded")) return;
  await set("categories",DEFAULT_CATEGORIES);
  await set("products",DEFAULT_PRODUCTS);
  await set("meta/seeded",true);
  const existingAdmin=await store.get("admin/password",{type:"json"});
  if(!existingAdmin){
    const adminId=process.env.ADMIN_ID || "saheliadmin";
    const adminPassword=process.env.ADMIN_PASSWORD || "Saheli@845107#2026";
    const adminEmail=process.env.ADMIN_EMAIL || "sahelibheraiti@gmail.com";
    const salt=crypto.randomBytes(16).toString("hex");
    await set("admin/password",{id:adminId,email:adminEmail,hash:hashPassword(adminPassword,salt),salt});
  }
}

export default async (req)=>{
  try{
    await seed();
    const url=new URL(req.url);
    const action=url.searchParams.get("action")||"";
    const method=req.method;

    if(action==="products" && method==="GET") return json({products:await get("products",DEFAULT_PRODUCTS)});
    if(action==="categories" && method==="GET") return json({categories:await get("categories",DEFAULT_CATEGORIES)});
    if(action==="payment-config" && method==="GET") return json({keyId:process.env.RAZORPAY_KEY_ID||""});
    if(action==="create-payment-order" && method==="POST") return await createPaymentOrder(await body(req));
    if(action==="verify-payment" && method==="POST") return await verifyPayment(await body(req));

    if(action==="customer" && method==="GET"){
      const phone=cleanPhone(url.searchParams.get("phone"));
      if(phone.length!==10) return json({error:"Invalid mobile number"},400);
      const c=await get(`customer/${phone}`,{phone,points:0,scratchCards:[],history:[],name:""});
      return json({customer:c});
    }

    if(action==="orders" && method==="GET"){
      if(!isAdmin(req)) return json({error:"Unauthorized"},401);
      return json({orders:await get("orders",[])});
    }
    if(action==="customers" && method==="GET"){
      if(!isAdmin(req)) return json({error:"Unauthorized"},401);
      const customers=await get("customers",[]);
      return json({customers});
    }

    if(action==="login" && method==="POST"){
      const b=await body(req);
      let admin=await get("admin/password",null);
      const suppliedId=String(b.id||"").trim();
      const suppliedPassword=String(b.password||"");
      const configuredId=process.env.ADMIN_ID || "saheliadmin";
      const configuredPassword=process.env.ADMIN_PASSWORD || "Saheli@845107#2026";

      // Recovery/first-login path: if the stored admin record is missing or was
      // created by an older deployment, the configured credentials can recreate it.
      if(suppliedId===configuredId && suppliedPassword===configuredPassword &&
         (!admin || admin.id!==configuredId || !passwordMatches(suppliedPassword,admin))){
        const salt=crypto.randomBytes(16).toString("hex");
        admin={id:configuredId,email:process.env.ADMIN_EMAIL || "sahelibheraiti@gmail.com",hash:hashPassword(configuredPassword,salt),salt};
        await set("admin/password",admin);
      }

      const idMatches=admin && (!admin.id || suppliedId===admin.id);
      if(!admin || !idMatches || !passwordMatches(suppliedPassword,admin))
        return json({error:"Invalid admin credentials"},401);
      return new Response(JSON.stringify({ok:true}),{headers:{
        "content-type":"application/json",
        "set-cookie":`saheli_admin=${makeSession()}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200`
      }});
    }
    if(action==="logout" && method==="POST"){
      return new Response(JSON.stringify({ok:true}),{headers:{
        "content-type":"application/json",
        "set-cookie":"saheli_admin=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0"
      }});
    }
    if(action==="change-password" && method==="POST"){
      if(!isAdmin(req)) return json({error:"Unauthorized"},401);
      const b=await body(req);
      if(String(b.newPassword||"").length<10) return json({error:"Password must be at least 10 characters"},400);
      const old=await get("admin/password",null);
      if(!passwordMatches(String(b.currentPassword||""),old)) return json({error:"Current password is incorrect"},400);
      const salt=crypto.randomBytes(16).toString("hex");
      await set("admin/password",{id:old.id || process.env.ADMIN_ID || "saheliadmin",email:old.email || process.env.ADMIN_EMAIL || "sahelibheraiti@gmail.com",hash:hashPassword(b.newPassword,salt),salt});
      return json({ok:true});
    }

    if(!isAdmin(req) && ["save-product","delete-product","save-category","delete-category","offline-sale","confirm-order","reset-data"].includes(action))
      return json({error:"Unauthorized"},401);

    if(action==="save-product" && method==="POST"){
      const b=await body(req);
      if(!b.name || !b.category || !Number.isFinite(Number(b.price))) return json({error:"Name, category and price are required"},400);
      const products=await get("products",DEFAULT_PRODUCTS);
      const p={id:b.id||"p"+Date.now(),name:String(b.name).trim(),category:String(b.category),price:Number(b.price),size:String(b.size||""),stock:Math.max(0,Number(b.stock||0)),image:String(b.image||""),description:String(b.description||"")};
      const i=products.findIndex(x=>x.id===p.id);
      if(i>=0) products[i]=p; else products.push(p);
      await set("products",products); return json({products});
    }
    if(action==="delete-product" && method==="POST"){
      const b=await body(req); const products=(await get("products",DEFAULT_PRODUCTS)).filter(x=>x.id!==b.id);
      await set("products",products); return json({products});
    }
    if(action==="save-category" && method==="POST"){
      const b=await body(req); const name=String(b.name||"").trim();
      if(!name) return json({error:"Category name required"},400);
      const cats=await get("categories",DEFAULT_CATEGORIES); if(!cats.includes(name)) cats.push(name);
      await set("categories",cats); return json({categories:cats});
    }
    if(action==="delete-category" && method==="POST"){
      const b=await body(req); const cats=(await get("categories",DEFAULT_CATEGORIES)).filter(x=>x!==b.name);
      await set("categories",cats); return json({categories:cats});
    }

    if(action==="offline-sale" && method==="POST"){
      return await processSale(await body(req),"offline");
    }
    if(action==="order" && method==="POST"){
      return json({error:"Online orders must be paid through Razorpay checkout."},400);
    }
    if(action==="confirm-order" && method==="POST"){
      if(!isAdmin(req)) return json({error:"Unauthorized"},401);
      const b=await body(req); const orders=await get("orders",[]);
      const i=orders.findIndex(x=>x.id===b.id); if(i<0) return json({error:"Order not found"},404);
      const o=orders[i]; if(o.status!=="Payment Verified") return json({error:"Only payment-verified orders can be confirmed."},400);
      const result=await awardLoyaltyForOrder(o); o.status="Confirmed"; o.confirmedAt=new Date().toISOString(); o.pointsAwarded=result.pointsAwarded; o.scratch=result.scratch||null;
      orders[i]=o; await set("orders",orders); return json({ok:true,order:o,pointsAwarded:result.pointsAwarded,scratch:result.scratch});
    }

    return json({error:"Unknown action"},404);
  }catch(e){
    console.error(e);
    return json({error:"Server error. Please check Netlify function logs."},500);
  }
};

async function createPaymentOrder(b){
  const phone=cleanPhone(b.phone), amount=Number(b.amount);
  if(String(b.pincode)!=="845107") return json({error:"Online delivery is available only in PIN 845107."},400);
  if(phone.length!==10) return json({error:"Valid 10-digit mobile number is required"},400);
  if(!Number.isFinite(amount)||amount<500) return json({error:"Minimum online order is ₹500."},400);
  if(!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return json({error:"Razorpay is not configured on the server yet."},500);
  const localId="ORD-"+Date.now().toString(36).toUpperCase();
  const auth=Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString("base64");
  const rr=await fetch("https://api.razorpay.com/v1/orders",{method:"POST",headers:{Authorization:`Basic ${auth}`,"Content-Type":"application/json"},body:JSON.stringify({amount:Math.round(amount*100),currency:"INR",receipt:localId,notes:{phone,name:String(b.name||"").slice(0,80),pincode:"845107"}})});
  const data=await rr.json(); if(!rr.ok) return json({error:data?.error?.description||"Unable to create Razorpay order"},500);
  const orders=await get("orders",[]);
  orders.unshift({id:localId,razorpayOrderId:data.id,phone,name:String(b.name||"").slice(0,80),source:"online",amount,status:"Payment Pending",createdAt:new Date().toISOString(),items:b.items||[],pincode:"845107",address:String(b.address||"").slice(0,300),pointsAwarded:0});
  await set("orders",orders);
  return json({ok:true,orderId:localId,razorpayOrderId:data.id,amount,currency:"INR",keyId:process.env.RAZORPAY_KEY_ID});
}

async function verifyPayment(b){
  const orderId=String(b.razorpay_order_id||""), paymentId=String(b.razorpay_payment_id||""), signature=String(b.razorpay_signature||"");
  if(!orderId||!paymentId||!signature) return json({error:"Missing Razorpay payment details"},400);
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET||"").update(`${orderId}|${paymentId}`).digest("hex");
  if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature))) return json({error:"Payment verification failed"},400);
  const orders=await get("orders",[]); const i=orders.findIndex(x=>x.razorpayOrderId===orderId);
  if(i<0) return json({error:"Order not found"},404);
  orders[i].razorpayPaymentId=paymentId; orders[i].status="Payment Verified"; orders[i].paymentVerifiedAt=new Date().toISOString();
  await set("orders",orders);
  return json({ok:true,order:orders[i],message:"Payment verified. Loyalty points will be awarded after admin confirmation."});
}

async function awardLoyaltyForOrder(order){
  const phone=cleanPhone(order.phone); const amount=Number(order.amount);
  const customer=await get(`customer/${phone}`,{phone,points:0,scratchCards:[],history:[],name:order.name||""});
  if(order.name) customer.name=String(order.name).slice(0,80);
  const date=today(); let awarded=0;
  if(amount>=200 && customer.lastPointDate!==date){ awarded=amount>=1000?2:1; customer.points=Number(customer.points||0)+awarded; customer.lastPointDate=date; }
  let scratch=null;
  while(customer.points>=10){ customer.points-=10; scratch={id:voucherCode(),amount:randomVoucher(),issuedAt:new Date().toISOString(),redeemed:false}; customer.scratchCards=[...(customer.scratchCards||[]),scratch]; }
  customer.history=[...(customer.history||[]),{date:new Date().toISOString(),source:"online-confirmed",amount,awarded,orderId:order.id}].slice(-100);
  await set(`customer/${phone}`,customer);
  const customers=await get("customers",[]); const ci=customers.findIndex(x=>x.phone===phone);
  const summary={phone,name:customer.name,points:customer.points,scratchCards:customer.scratchCards.length,lastPurchase:amount,lastPointDate:customer.lastPointDate};
  if(ci>=0) customers[ci]=summary; else customers.push(summary); await set("customers",customers);
  return {pointsAwarded:awarded,scratch,customer};
}

async function processSale(b,source){
  const phone=cleanPhone(b.phone), amount=Number(b.amount);
  if(phone.length!==10) return json({error:"Valid 10-digit mobile number is required"},400);
  if(!Number.isFinite(amount)||amount<=0) return json({error:"Invalid purchase amount"},400);
  const customer=await get(`customer/${phone}`,{phone,points:0,scratchCards:[],history:[],name:String(b.name||"")});
  if(b.name) customer.name=String(b.name).slice(0,80);
  const date=today(); let awarded=0;
  if(amount>=200 && customer.lastPointDate!==date){ awarded=amount>=1000?2:1; customer.points=Number(customer.points||0)+awarded; customer.lastPointDate=date; }
  let scratch=null; while(customer.points>=10){customer.points-=10;scratch={id:voucherCode(),amount:randomVoucher(),issuedAt:new Date().toISOString(),redeemed:false};customer.scratchCards=[...(customer.scratchCards||[]),scratch];}
  customer.history=[...(customer.history||[]),{date:new Date().toISOString(),source,amount,awarded}].slice(-100); await set(`customer/${phone}`,customer);
  const orders=await get("orders",[]); const order={id:"ORD-"+Date.now().toString(36).toUpperCase(),phone,name:customer.name,source,amount,status:source==="online"?"Pending":"Completed",createdAt:new Date().toISOString(),items:b.items||[],pincode:b.pincode||"845107",pointsAwarded:awarded}; orders.unshift(order); await set("orders",orders);
  const customers=await get("customers",[]); const ci=customers.findIndex(x=>x.phone===phone); const summary={phone,name:customer.name,points:customer.points,scratchCards:customer.scratchCards.length,lastPurchase:amount,lastPointDate:customer.lastPointDate}; if(ci>=0)customers[ci]=summary;else customers.push(summary);await set("customers",customers);
  return json({ok:true,order,customer,pointsAwarded:awarded,scratch});
}
